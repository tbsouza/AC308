/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.entidades;

/**
 *
 * @author tbsou
 */
public class Pediddo {
 
    private int idPedido;
    private String pDescricao;
    private int cliente_idCliente;
    
    
    
    
    
}
