/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.entidades;

import br.inatel.DAO.clienteDAO;

/**
 *
 * @author tbsou
 */
public class Cliente {
    
    private String Nome;
    private String Endereco;
    private String Cartao;
    private String Senha;
    private int idCliente;

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    public String getCartao() {
        return Cartao;
    }

    public void setCartao(String Cartao) {
        this.Cartao = Cartao;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    } 
    
}
