/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.DAO;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tbsou
 */

public class copoDAO {
    
    // Abre conexao com o Banco     
    Connection con = null;
    
    // Recebe a resposta da consulta do banco     
    ResultSet rs = null;
    
    // Permite o envio de comandos ESTATICOS SQL para o banco    
    Statement st = null;
    
    // Permite o envio de comandos DINAMICOS SQL para o banco     
    PreparedStatement pst = null;
    
    // String indicando com qual schema havera conexao (livrariaacme)     
    // Obs: Cada driver possui uma sintaxe diferente para a url
    String url = "jdbc:mysql://localhost:3306/ac308";
    
    // Usuario do Banco     
    String user = "root";
    
    // Senha do Banco     
    String password = "root"; 
    
    // Driver do banco de dados jdbc
    private final String driver = "com.mysql.jdbc.Driver";

    //--------------------------------------------------------------------  

    int tamanho;
    float preco;

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }
    
   
    
    // (0) CONNECT: Metodo usado para abrir conexao com o banco
    public void conectaBanco(){
    
        try {// Objeto que estabelece uma conexao com o Banco de Dados, usando a URL, usuario e senha.
            Class.forName( driver );
            System.setProperty(driver, driver);
            con = (Connection) DriverManager.getConnection(url, user, password);
        } catch (SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } catch( ClassNotFoundException ex ){
            System.out.println("Erro: Class not found!");
        } 
        
    }
    
    // Retorna o preco do copo
    public float selectPreco(){
    
        // Conecta com o Banco         
        conectaBanco();
    
         try { // Preparo a consulta
            
            pst = (PreparedStatement) con.prepareStatement("SELECT pPreco FROM preco WHERE pTamanho = ?");
            
            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setInt(1, getTamanho());
           
            // Executo a pesquisa
            rs = pst.executeQuery();
            
            System.out.println("Success Aqui! Select Preco Copo");
            
           preco=0;
            
            while ( rs.next() ){
                preco = rs.getFloat(1);
            }
            
            return preco;
            
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage() ); 
            }  
            
        } // end finally
         
        return 0;
    }
    
    
    
    
    
    
    
    
    
    
}
