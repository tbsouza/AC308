package br.inatel.DAO;

import br.inatel.entidades.Cliente;
import br.inatel.entidades.Ingredientes;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class clienteDAO {

    // Abre conexao com o Banco     
    Connection con = null;
    
    // Recebe a resposta da consulta do banco     
    ResultSet rs = null;
    
    // Permite o envio de comandos ESTATICOS SQL para o banco    
    Statement st = null;
    
    // Permite o envio de comandos DINAMICOS SQL para o banco     
    PreparedStatement pst = null;
    
    // String indicando com qual schema havera conexao (livrariaacme)     
    // Obs: Cada driver possui uma sintaxe diferente para a url
    String url = "jdbc:mysql://localhost:3306/ac308";
    
    // Usuario do Banco     
    String user = "root";
    
    // Senha do Banco     
    String password = "root"; 
    
    // Driver do banco de dados jdbc
    private final String driver = "com.mysql.jdbc.Driver";

    //--------------------------------------------------------------------     

    //CADA COLUNA DA TABELA DEVE POSSUIR UMA VARIAVEL QUE A REPRESENTE NA SUA RESPECTIVA DAO
    private String Nome;
    private String Endereco;
    private String Cartao;
    private String Senha;

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    public String getCartao() {
        return Cartao;
    }

    public void setCartao(String Cartao) {
        this.Cartao = Cartao;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    } 
    
    // IMPLEMENTANDO O CRUD DO CLIENTE
    
    // (0) CONNECT: Metodo usado para abrir conexao com o banco
    public void conectaBanco(){
    
        try {// Objeto que estabelece uma conexao com o Banco de Dados, usando a URL, usuario e senha.
            Class.forName( driver );
            System.setProperty(driver, driver);
            con = (Connection) DriverManager.getConnection(url, user, password);
        } catch (SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } catch( ClassNotFoundException ex ){
            System.out.println("Erro: Class not found!");
        } 
        
    }
    
    
    //(1) INSERT: Insere novo Livro.    
    public void insere(){
    
        // Conecta com o Banco         
        conectaBanco();
        
        try { // Preparo a insercao
            
            pst = (PreparedStatement) con.prepareStatement("INSERT INTO cliente (cNome, cEndereco, cCartao, cSenha) VALUES (?,?,?,?)");
            
            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setString(1, getNome() );
            pst.setString(2, getEndereco());
            pst.setString(3, getCartao() );
            pst.setString(4, getSenha() );
           
            // Executo a pesquisa
            pst.executeUpdate();
            System.out.println("Success! Insere Cliente");
     
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage() ); 
            }  
            
        } // end finally
    } // end insere
    
    
    // (2) Valida login
    public Boolean validaCadastro(){
    
        // Conecta com o Banco         
        conectaBanco();
    
         try { // Preparo a consulta
            
            pst = (PreparedStatement) con.prepareStatement("SELECT * FROM cliente WHERE cNome LIKE ?");
            
            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setString(1, getNome() );
            
            // Executo a pesquisa
            rs = pst.executeQuery();
            
            System.out.println("Success! Valida Cadastro");
            
            int cont=0;
            
            // conta quantos resultados restornou
            while (rs.next()) { cont++; }
            
            if( cont == 0 ){ // nenhum nome igual
                return true;
            }
           
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage() ); 
            }  
            
        } // end finally
    
        return false;
         
    } // end select
    
    
    // (2) Valida login
    public int validaLogin(){
    
        // Conecta com o Banco         
        conectaBanco();
    
         try { // Preparo a consulta
            
            pst = (PreparedStatement) con.prepareStatement("SELECT cSenha, cNome FROM cliente WHERE cNome LIKE ?");
            
            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setString(1, getNome() );
           
            // Executo a pesquisa
            rs = pst.executeQuery();
            
            System.out.println("Success! Valida Login");
            
            while (rs.next()) { 
                 
                 String senha = rs.getString(1);
                 String nome = rs.getString(2);
                 
                 if( nome.equals(getNome()) ){
                     // user cadastrado
                     
                     if( senha.equals(getSenha()) ){
                         return 1;
                     }
                     
                     return 2;
                 }
            }
            
            return 0;
            
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage() ); 
            }  
            
        } // end finally
    
        return 0;
         
    } // end select
    
    
    // (3) Seleciona usuário atual
    public Cliente selectUser(){
    
        // Conecta com o Banco         
        conectaBanco();
    
        try { // Preparo a consulta
            
            pst = (PreparedStatement) con.prepareStatement("SELECT * FROM cliente WHERE cNome LIKE ?");
            
            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setString(1, getNome() );
           
            // Executo a pesquisa
            rs = pst.executeQuery();
            
            System.out.println("Success! Select User");
            
            Cliente cliente = new Cliente();
            
            while ( rs.next() ){
                cliente.setEndereco( rs.getString(2) );
                cliente.setCartao( rs.getString(3) );
                cliente.setSenha( rs.getString(4) );
                cliente.setNome( rs.getString(5) );
            }
            
            return cliente;
            
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage() ); 
            }  
            
        } // end finally
         
        return null;

    } // end select user
    
    
    // Seleciona id do cliente atual
    public int selectIdCliente(){
    
        // Estabelece conexão com o Banco         
        conectaBanco();
    
        try { // Preparo a consulta
            
            pst = (PreparedStatement) con.prepareStatement("SELECT idCliente FROM cliente WHERE cNome LIKE ?");
                        
            pst.setString(1, getNome() );
           
            // Executa a pesquisa
            rs = pst.executeQuery();
            
            int id=0;
            
            // REsultado da pesquisa
            while ( rs.next() ){
                 id = rs.getInt(1);
            }
            
            System.out.println("Success! Select ID: " + id);
            
            return id;
            
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Error: Cant close connection!" + ex.getMessage() ); 
            }  
            
        } // end finally
         
        return 0;

    } // end select id
    
    public Boolean isAdm(){
    
        // Estabelece conexão com o Banco         
        conectaBanco();
    
        try { // Preparo a consulta
            
            pst = (PreparedStatement) con.prepareStatement("SELECT cAdm FROM cliente WHERE cNome LIKE ?");
                        
            pst.setString(1, getNome() );
           
            // Executa a pesquisa
            rs = pst.executeQuery();
            
            int adm=0;
            
            // REsultado da pesquisa
            while ( rs.next() ){
                 adm = rs.getInt(1);
            }
            
            System.out.println("Success! Select ADM: " + adm);
            
            return (adm==1);
            
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Error: Cant close connection!" + ex.getMessage() ); 
            }  
            
        } // end finally
         
        return false;
    }
    
    // Deleta cliente atual
    public void deleteCliente(){
    
        // Estabelece conexão com o Banco         
        conectaBanco();
    
        try { // Preparo a consulta
            
            pst = (PreparedStatement) con.prepareStatement("DELETE FROM cliente WHERE cNome LIKE ?");
                        
            pst.setString(1, getNome() );
           
            // Executa a pesquisa
            pst.executeUpdate();
            
            System.out.println("Success! Deleta Cliente");
            
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Error: Cant close connection!" + ex.getMessage() ); 
            }  
            
        } // end finally

    } // end delata cliente
    
    
    public ArrayList<Cliente> selectClientes(){
    
        // Conecta com o Banco         
        conectaBanco();

        try { // Preparo a consulta

            ArrayList<Cliente> clientes = new ArrayList<>();
            
                    
            st = (Statement) con.createStatement();

            rs = this.st.executeQuery("SELECT * FROM cliente");

            while (rs.next()) {
                
                Cliente cliente = new Cliente();
                
                cliente.setCartao( rs.getString("cCartao") );
                cliente.setEndereco( rs.getString("cEndereco") );
                cliente.setIdCliente( rs.getInt( "idCliente" ) );
                cliente.setNome( rs.getString("cNome") );
                
                clientes.add(cliente);
            }

            System.out.println("Success! Select Ingredientes ");

            return clientes;

        } catch (SQLException ex) {
            System.out.println("Erro: Conexão Banco Ingrediente! " + ex.getMessage());
        } finally { // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes

            System.gc();
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage());
            }

        } // end finally

        return null;
    }
    
    
    
    
    
    
    
    
    
    
} // end class clienteDAO
