/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.DAO;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author tbsou
 */
public class pedidoDAO {
    
    // Abre conexao com o Banco     
    Connection con = null;
    
    // Recebe a resposta da consulta do banco     
    ResultSet rs = null;
    
    // Permite o envio de comandos ESTATICOS SQL para o banco    
    Statement st = null;
    
    // Permite o envio de comandos DINAMICOS SQL para o banco     
    PreparedStatement pst = null;
    
    // String indicando com qual schema havera conexao (livrariaacme)     
    // Obs: Cada driver possui uma sintaxe diferente para a url
    String url = "jdbc:mysql://localhost:3306/ac308";
    
    // Usuario do Banco     
    String user = "root";
    
    // Senha do Banco     
    String password = "root"; 
    
    // Driver do banco de dados jdbc
    private final String driver = "com.mysql.jdbc.Driver";

    //--------------------------------------------------------------------     

    //CADA COLUNA DA TABELA DEVE POSSUIR UMA VARIAVEL QUE A REPRESENTE NA SUA RESPECTIVA DAO
    int idIngrediente;
    int idCliente;
    int tamanho;
    float precoTamanho;
    float precoIngredi;
    float precoTotal;
    int qtdd;
    String ingrediente;
    String cliente;

    public float getPrecoTamanho() {
        return precoTamanho;
    }

    public void setPrecoTamanho(float precoTamanho) {
        this.precoTamanho = precoTamanho;
    }
    
    public float getPrecoTotal() {
        return precoTotal;
    }

    public void setPrecoTotal(float precoTotal) {
        this.precoTotal = precoTotal;
    }
    
    public float getPrecoIngredi() {
        return precoIngredi;
    }

    public void setPrecoIngredi(float precoIngredi) {
        this.precoIngredi = precoIngredi;
    }

    public String getIngrediente() {
        return ingrediente;
    }

    public void setIngrediente(String ingrediente) {
        this.ingrediente = ingrediente;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public int getIdIngrediente() {
        return idIngrediente;
    }

    public void setIdIngrediente(int idIngrediente) {
        this.idIngrediente = idIngrediente;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public int getQtdd() {
        return qtdd;
    }

    public void setQtdd(int qtdd) {
        this.qtdd = qtdd;
    }
    
    
     // (0) CONNECT: Metodo usado para abrir conexao com o banco
    public void conectaBanco(){
    
        try {// Objeto que estabelece uma conexao com o Banco de Dados, usando a URL, usuario e senha.
            Class.forName( driver );
            System.setProperty(driver, driver);
            con = (Connection) DriverManager.getConnection(url, user, password);
        } catch (SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } catch( ClassNotFoundException ex ){
            System.out.println("Erro: Class not found!");
        } 
        
    }
    
    
    //(1) INSERT: Insere novo Pedido.    
    public void insere(){
    
        // Conecta com o Banco         
        conectaBanco();
    
        fazTudo();
        
        try { // Preparo a insercao
            
            pst = (PreparedStatement) con.prepareStatement("INSERT INTO pedido (ingrediente_idIngrediente, cliente_idCliente, pTamanho, pPreco, pQuantidade) VALUES (?,?,?,?,?)");
            
            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setInt(1, getIdIngrediente());
            pst.setInt(2, getIdCliente());
            pst.setInt(3, getTamanho() );
            pst.setFloat(4, getPrecoTotal());
            pst.setInt(5, getQtdd() );
           
            // Executo a pesquisa
            pst.executeUpdate();
            System.out.println("Success Insere Pedido!");
            
            //System.out.println("Insere Pedido: ID Cliente " + getIdCliente() );
     
        } catch(SQLException ex){
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } finally{ // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes
        
            try{
                if(rs != null){ rs.close(); }
                if(pst != null){ pst.close(); }
                if(con != null){ con.close(); } 
                
            }  catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage() ); 
            }  
            
        } // end finally
    } // end insere
    
     // preco do ingrediente adicional escolhido
    public void calculaTotal() {
        
        ingredienteValue();
        tamanhoValue();
        
        System.out.println("calcula Total ingrediente " + getPrecoIngredi());
        System.out.println("calcula Total tamanho " + getPrecoTamanho() );
        
        
        float total = 0;
        
        total += getPrecoIngredi();
        total += getPrecoTamanho();
        total *= getQtdd();
        
        setPrecoTotal( total );
    }
    
    public void ingredienteValue(){
    
        ingredienteDAO dao = new ingredienteDAO();
        
        dao.setNome( getIngrediente() );
        
        // Preco do ingrediente
        setPrecoIngredi( dao.selectPreco() );
    }
    
    // preco do copo
    public void tamanhoValue(){
        copoDAO dao = new copoDAO();
        
        dao.setTamanho( getTamanho() );
  
        setPrecoTamanho(dao.selectPreco() );
    }
    
    // Select id do Ingredientes
    public void selecIdIngrediente(){
        ingredienteDAO dao = new ingredienteDAO();
        dao.setNome( getIngrediente() );
        
        setIdIngrediente( dao.selectID() );
    }
    
    // Select id do cliente
    public void selecIdCliente(){
        clienteDAO dao = new clienteDAO();
        
        dao.setNome( getCliente() );
        
        setIdCliente( dao.selectIdCliente() );
    }
    
    
    private void fazTudo(){
        selecIdCliente();
        selecIdIngrediente();
        calculaTotal();
    }
    
    
} // end class
