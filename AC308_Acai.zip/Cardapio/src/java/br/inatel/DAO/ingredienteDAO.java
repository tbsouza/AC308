/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.DAO;

import br.inatel.entidades.Ingredientes;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.io.Serializable;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author tbsou
 */
public class ingredienteDAO implements Serializable {

    // Abre conexao com o Banco     
    Connection con = null;

    // Recebe a resposta da consulta do banco     
    ResultSet rs = null;

    // Permite o envio de comandos ESTATICOS SQL para o banco    
    Statement st = null;

    // Permite o envio de comandos DINAMICOS SQL para o banco     
    PreparedStatement pst = null;

    // String indicando com qual schema havera conexao (livrariaacme)     
    // Obs: Cada driver possui uma sintaxe diferente para a url
    String url = "jdbc:mysql://localhost:3306/ac308";

    // Usuario do Banco     
    String user = "root";

    // Senha do Banco     
    String password = "root";

    // Driver do banco de dados jdbc
    private final String driver = "com.mysql.jdbc.Driver";

    //--------------------------------------------------------------------  
    String Nome;
    String Sabor;
    float Valor;
    int id;

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getSabor() {
        return Sabor;
    }

    public void setSabor(String Sabor) {
        this.Sabor = Sabor;
    }

    public float getValor() {
        return Valor;
    }

    public void setValor(float Valor) {
        this.Valor = Valor;
    }

    // (0) CONNECT: Metodo usado para abrir conexao com o banco
    public void conectaBanco() {

        try {// Objeto que estabelece uma conexao com o Banco de Dados, usando a URL, usuario e senha.
            Class.forName(driver);
            System.setProperty(driver, driver);
            con = (Connection) DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            System.out.println("Erro: Conexão Banco! " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("Erro: Class not found!");
        }

    }

    // Retorna o preco do ingrediente
    public float selectPreco() {

        // Conecta com o Banco         
        conectaBanco();

        try { // Preparo a consulta

            pst = (PreparedStatement) con.prepareStatement("SELECT iValor FROM ingredientes WHERE iNome = ?");

            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setString(1, getNome());

            // Executo a pesquisa
            rs = pst.executeQuery();

            Valor = 0;

            while (rs.next()) {
                Valor = rs.getFloat(1);
            }

            System.out.println("Success Aqui! Select Preco Ingrediente " + Valor);

            return Valor;

        } catch (SQLException ex) {
            System.out.println("Erro: Conexão Banco Ingrediente! " + ex.getMessage());
        } finally { // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes

            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage());
            }

        } // end finally

        return 0;
    }

    // Retorna o id do ingrediente
    public int selectID() {

        // Conecta com o Banco         
        conectaBanco();

        try { // Preparo a consulta

            pst = (PreparedStatement) con.prepareStatement("SELECT idIngredientes FROM ingredientes WHERE iNome = ?");

            // Cada numero indica a posicao que o valor sera inserido nas ? acima             
            pst.setString(1, getNome());

            // Executo a pesquisa
            rs = pst.executeQuery();

            System.out.println("Success Aqui! Select ID Ingrediente");

            id = 0;

            while (rs.next()) {
                id = rs.getInt(1);
            }

            return id;

        } catch (SQLException ex) {
            System.out.println("Erro: Conexão Banco Ingrediente! " + ex.getMessage());
        } finally { // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes

            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage());
            }

        } // end finally

        return 0;
    }

    // Retorna o id do ingrediente
    public ArrayList<Ingredientes> selectIngredientes() {

        // Conecta com o Banco         
        conectaBanco();

        try { // Preparo a consulta

            ArrayList<Ingredientes> ingredientes = new ArrayList<>();

            st = (Statement) con.createStatement();

            rs = this.st.executeQuery("SELECT * FROM ingredientes");

            while (rs.next()) {

                Ingredientes ingred = new Ingredientes();

                ingred.setIdIngrediente(rs.getInt("idIngredientes"));
                ingred.setNome(rs.getString("iNome"));
                ingred.setSabor(rs.getString("iSabor"));
                ingred.setValor(rs.getFloat("iValor"));

                ingredientes.add(ingred);
            }

            System.out.println("Success! Select Ingredientes ");

            System.gc();

            return ingredientes;

        } catch (SQLException ex) {
            System.out.println("Erro: Conexão Banco Ingrediente! " + ex.getMessage());
        } finally { // Independente se a conexao deu certo ou errado, fecha as conexoes pendentes

            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                System.out.println("Erro: Conexão não pode ser fechada!" + ex.getMessage());
            }

        } // end finally

        return null;
    }

}
