
package br.inatel.bean;

import br.inatel.DAO.clienteDAO;
import br.inatel.entidades.Cliente;
import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.application.NavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public class beanCliente {
    
    private String Nome;
    private String Endereco;
    private String Cartao;
    private String Senha;
    private Boolean adm;
    private ArrayList<Cliente> clientes;
    private Cliente cliente;

    public ArrayList<Cliente> getList() {
        clienteDAO dao = new clienteDAO();
        
        //setClientes( dao.selectClientes );
        
        return clientes;
    }
    
    @PostConstruct
    public void init() {
        clientes = getList();
    }
    
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    public Boolean getAdm() {
        return adm;
    }

    public void setAdm(Boolean adm) {
        this.adm = adm;
    }
            
    // Nome do cliente atual
    private static String nomeAtual;

    
    // Getters and Setters
    public String getNomeAtual() {
        return nomeAtual;
    }

    public void setNomeAtual(String nomeAtual) {
        beanCliente.nomeAtual = nomeAtual;
    }
    
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    public String getCartao() {
        return Cartao;
    }

    public void setCartao(String Cartao) {
        this.Cartao = Cartao;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    } 
    
    // Cadastro de novo usuário
    public void cadastro(){
  
        // Trim - retira espaços vazios antes e depois
        String nSenha = getSenha().trim();
        String nCartao = getCartao().trim();
        String nNome = getNome().trim();
        String nEndereco = getEndereco().trim();
        
        // verifica se ha algum campo vazio
        if( nCartao.equals("") || nNome.equals("") || nSenha.equals("") || nEndereco.equals("")){
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atenção!", "Algum campo está vazio"));
        }else{
            // cria instancia de DAO
            clienteDAO dao = new clienteDAO();

            dao.setNome( nNome );
            dao.setCartao( nCartao );
            dao.setEndereco( nEndereco );
            dao.setSenha( nSenha );

            if( dao.validaCadastro() ){
                
                // se dados forem validos, insere novo cliente
                dao.insere();

                // limpa os campos
                setNome( "" );
                setCartao( "" );
                setEndereco( "" );
                setSenha( "" );

                // Exibe mensagem de sucesso
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "◕‿◕", "Usuário Cadastrado com sucesso"));
            }else{
                // Exibe mensagem de erro
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atenção!", "Nome de usuário já existe"));
            }
            
        } // end if-else
        
    } // end cadastro
    
    
    // Validação do login
    public void validaLogin(){
    
        // Trim - retira espaços vazios antes e depois da String
        String nSenha = getSenha().trim();
        String nNome = getNome().trim();
        
        if( nNome.equals("") || nSenha.equals("") ){
            // Campo vazio
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atenção!", "Algum campo está vazio"));
        }else{
        
            // cria instancia de DAO
            clienteDAO dao = new clienteDAO();

            dao.setNome( nNome );
            dao.setSenha( nSenha );

            // Faz validação do login
            int result = dao.validaLogin();

            if( result == 0 ){
                // usuario nao cadastrado
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atenção!", "Usuário não cadastrado"));
            }else if( result == 2 ){
                // Senha incorreta
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atenção!", "Senha incorreta"));
            }else{ // Login efetuado com sucesso

                // Salva o nome do usuario atual
                setNomeAtual( nNome );
                
                // Salva id e nome do cliente atual no pedido
                beanPedido.setIdCliente( clienteAtualId(nNome) );
                beanPedido.setNomeCliente( getNomeAtual() );
                
                System.out.println( "Nome atual: " + getNomeAtual() + " nNome: " + nNome );
                
                
                // Verifica se é adm
                if( getAdm() && isAdm() ){  // é adm
                    // Muda para pagina de menu de adm
                    FacesContext context = FacesContext.getCurrentInstance();
                    NavigationHandler navigationHandler = context.getApplication().getNavigationHandler();
                    navigationHandler.handleNavigation(context, null, "menuAdm");
                }else if( getAdm()==false ){
                    // Muda para pagina de menu de cliente
                    FacesContext context = FacesContext.getCurrentInstance();
                    NavigationHandler navigationHandler = context.getApplication().getNavigationHandler();
                    navigationHandler.handleNavigation(context, null, "menu");
                }else if( getAdm() && !isAdm() ){
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Atenção!", "Você não é Administrador"));
                }
            } 
        }
        
    } // end validaLogin
    
    
    // Exibe perfil do usuário atual
    public void exibePerfil(){
    
        // cria instancia de DAO
        clienteDAO dao = new clienteDAO();
        
        dao.setNome( getNomeAtual() );
        
        // Faz a consulta dos dados do usuário
        Cliente cliente = dao.selectUser();
        
        // Exibe os dados no primefaces
        setEndereco( cliente.getEndereco() );
        setNome( cliente.getNome() );
        setSenha( cliente.getSenha() );
        setCartao( cliente.getCartao() );
    
    } // end exibePerfil
    
    
    public int clienteAtualId( String nome ){
    
        clienteDAO dao = new clienteDAO();
        
        dao.setNome( nome );
        
        int id = dao.selectIdCliente();
        
        System.out.println("Cliente atual id: " + id );
        
        return id;
    } // end clienteAtualId
    
    
    public Boolean isAdm(){
    
        clienteDAO dao = new clienteDAO();
        
        dao.setNome( getNomeAtual() );
        
        return dao.isAdm();
    }
    
   public void conta(){
   
       clienteDAO dao = new clienteDAO();
       
       dao.setNome( getNomeAtual() );
       
       dao.deleteCliente();
       
       System.out.println( "Cliente excluido com sucesso!" );
       
       // Muda para pagina de inicio
       FacesContext context = FacesContext.getCurrentInstance();
       NavigationHandler navigationHandler = context.getApplication().getNavigationHandler();
       navigationHandler.handleNavigation(context, null, "index");
       
   }
    
    
    
   
   
   
} // end class
