/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.bean;

import br.inatel.DAO.ingredienteDAO;
import br.inatel.entidades.Ingredientes;
import java.io.Serializable;
import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author tbsou
 */
@ManagedBean
@SessionScoped
public class beanIngrediente implements Serializable {

    private Ingredientes ingrediente = null;
    private ArrayList<Ingredientes> ingredientes;

    public ArrayList<Ingredientes> getIngredientes() {
        setIngredientes( getList() );
        return ingredientes;
    }

    public void setIngredientes(ArrayList<Ingredientes> ingredientes) {
        this.ingredientes = ingredientes;
    }

    public Ingredientes getIngrediente() {
        return ingrediente;
    }

    public void setIngrediente(Ingredientes ingrediente) {
        this.ingrediente = ingrediente;
    }

    public ArrayList<Ingredientes> getList() {
        ingredienteDAO dao = new ingredienteDAO();

        // Seleciona todos os ingredientes       
        return dao.selectIngredientes();
    }

    @PostConstruct
    public void init() {
        ingredientes = getList();
    }

}
