/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.bean;

import java.util.ArrayList;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author tbsou
 */
@ManagedBean
public class beanImagem {

    private ArrayList<String> images;
    private int i;

    public beanImagem() {
        
        images = new ArrayList<>();
        
        for (i = 1; i <= 4; i++) {
            images.add("img" + i + ".png");
        }
    }

    public ArrayList<String> getImages() {
        return images;
    }

    public void setImages(ArrayList<String> images) {
        this.images = images;
    }

}
