/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.inatel.bean;

import br.inatel.DAO.clienteDAO;
import br.inatel.DAO.pedidoDAO;
import java.text.DecimalFormat;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

/**
 *
 * @author tbsou
 */

@ManagedBean
public class beanPedido {
    
    int idIngrediente;
    static int idCliente;
    int tamanho = 100;
    float preco;
    float precoIngrediente;
    int qtdd = 1;
    String ingrediente;
    static String nomeCliente;

    public static String getNomeCliente() {
        return nomeCliente;
    }

    public static void setNomeCliente(String nomeCliente) {
        beanPedido.nomeCliente = nomeCliente;
    }
    
    public float getPrecoIngrediente() {
        return precoIngrediente;
    }

    public void setPrecoIngrediente(float precoIngrediente) {
        this.precoIngrediente = precoIngrediente;
    }

    public String getIngrediente() {
        return ingrediente;
    }

    public void setIngrediente(String ingrediente) {
        this.ingrediente = ingrediente;
    }
    
    public int getIdIngrediente() {
        return idIngrediente;
    }

    public  void setIdIngrediente(int idIngrediente) {
        this.idIngrediente = idIngrediente;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public static void setIdCliente(int id) {
        idCliente = id;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getQtdd() {
        return qtdd;
    }

    public void setQtdd(int qtdd) {
        this.qtdd = qtdd;
    }
    
    public void finalizaPedido(){
    
        // Objeto de pedido
        pedidoDAO pedDAO = new pedidoDAO();
        
        // Salva nome do cliente
        clienteDAO cliDAO = new clienteDAO();
        cliDAO.setNome( getNomeCliente() );
        
        pedDAO.setCliente( getNomeCliente() );
        
        // salva id do cliente
        pedDAO.setIdCliente( getIdCliente() );
        
        // Salva nome do ingrediente
        pedDAO.setIngrediente( getIngrediente() );
        
        // seleciona id do ingrediente
        pedDAO.selecIdIngrediente();
        
        // salva tamanho do copo
        pedDAO.setTamanho( getTamanho() );
        
        // salva quantidade de açai comprados
        pedDAO.setQtdd( getQtdd() );
        
        // Calcula o preço do ingrediente
        pedDAO.ingredienteValue();
        
        // Salva o preco do ingrediente
        pedDAO.setPrecoIngredi( getPrecoIngrediente() );
        
        // Calcula o valor total
        pedDAO.calculaTotal();
        
        // atualiza a variavel do bean (html)
        setPreco( pedDAO.getPrecoTotal() );
        
        // insere o novo pedido no banco
        pedDAO.insere();

        // limpa campos
        setIngrediente("");
        setPreco( 0 );
        setPrecoIngrediente( 0 );
        setQtdd( 1 );
        setTamanho(100);
        setIdIngrediente( 0 );
       
        // menssagem ao usuario
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "", "Pedido realizado com sucesso"));
    }
    
    // Calcula o preco total do pedido
    public void calculaPreco(){
    
        pedidoDAO pedDAO = new pedidoDAO();
        
        // Salva nome do ingrediente
        pedDAO.setIngrediente( getIngrediente() );
        
        // salva tamanho do copo
        pedDAO.setTamanho( getTamanho() );
        
        // salva quantidade de açai comprados
        pedDAO.setQtdd( getQtdd() );
        
        // Calcula o preço do ingrediente
        pedDAO.ingredienteValue();
        
        // Salva o preco do ingrediente
        pedDAO.setPrecoIngredi( getPrecoIngrediente() );
        
        // Calcula o valor total
        pedDAO.calculaTotal();
        
        float preco = pedDAO.getPrecoTotal();
        
        // atualiza a variavel do bean (html)
        setPreco( preco );
    }
    
}
